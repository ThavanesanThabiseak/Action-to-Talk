# Semester-Project
I have developed a Library Management System, using the all concepts of Object Oriented Programming in Java which were taught to us during the class and lab. The program is totally console based. The Library Management System includes functions display students, display books, issue library card, issue book, add book, return book, my account etc.

The concepts used in this program:

1- OOP [object-oriented programming]: All the basic OOP concepts from lab 1 till 3.

2- Inheritance.

3- Abstract class.

4- Encapsulation.

5- Constructors: default and other needed constructors.

6- Interface: The use of abstract class to achieve abstraction however the purpose of both interface and abstract classes are same.

7- Static Data members and Methods.

8- Composition.

9-Non primitive type return from function.

10- Array list 

11- File handling: (Book.txt, Student.txt)

12-Exceptions and Error Handling.


Classes

•	Objectmodelpackage(main)

•	Book

•	Books

•	RulesResultSet

•	Library(extends Institute class)

•	Student

•	Institute(abstract class)

